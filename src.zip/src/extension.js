

export const tableau = window.tableau;